(this file is outdated.)

{
    "pa": "North Omotic",
    "ch": "Wolaytta",
    "be": "b",
    "af": "w",
    "en": "V_V",
    "sr": [
        "id"
    ],
    "or": "Mecislau",
    "re": "number",
    "no": ""
}

{
    "parent": "North Omotic",
    "child": "Wolaytta",
    "before": "b",
    "after": "w",
    "environment": "V_V",
    "sources": [
        "id"
    ],
    "original_contributor": "Mecislau",
    "reliability": "number",
    "notes": ""
}

{
    "before": "b",
    "after": "w",
    "environment": "V_V",
    "sources": [
        "id"
    ],
    "original_contributor": "Mecislau",
    "reliability": "number",
    "notes": "",
    "type": "Lenition",
    "subtype": "Final Devoicing",
    "name": "l-Deletion",
    "link": ""
}

https://chridd.nfshost.com/diachronica/

https://en.wikipedia.org/wiki/Phonological_rule

https://regexr.com/





() (.*) to (\w*)\n*(.*)

{\n    {\n        "metadata": {\n            "parent": $2,\n            "child": $3,\n            "contributor": TODO!\n            "source": "$4",\n            "family": TODO\n            "subfamily": TODO 


(.*) → ([^/\n]*)\/?(.*)

{\n    "before": "$1",\n    "after": "$2",\n    "env": "$3",\n    "src": [\n        "0"\n    ],\n    "or_auth": "Mecislau",\n    "rel": "unchecked",\n    "tag": [\n        ""\n    ],\n    "note": [\n        ""\n    ],\n\n}\n





new: 

([+-]) 

$1

(\S*) (\S*) ?(\S*)? → ([^/\n ]*) ([^/\n ]*)? ?([^/\n ]*)?\/?(.*)

$1 → $4\n\n$2 → $5\n\n$3 → $6


 → \n\n
 
Replace


(.*) → ([^/\n]*)\/?(.*)

{\n    "before": "$1",\n    "after": "$2",\n    "env": "$3",\n    "rel": "unchecked",\n    "tag": [""],\n    "note": [\n        ""\n    ],\n    "type": "",\n    "subtype": "",\n    "name": "",\n    "link": [""]\n},\n

,

        {
            "metadata": {
                "parent": "North Omotic", 
                "child": "North Omotic",
                "or_contr": "Mecislau",
                "source": "0",
                "note": [
                    ""
                ]
            },
            "changeset": [
                
            ]
        }
        

@from("Proto-Afro-Asiatic") + @before("dz")

@chart()


from:(Proto-Afro-Asiatic) + before:(dz)